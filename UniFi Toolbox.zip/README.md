# UniFi Toolbox

Folgende Module beinhaltet das UniFi Toolbox Repository:

- __UniFi Presence Manager__ ([Dokumentation](UniFi%20Presence%20Manager))  
	Kurze Beschreibung des Moduls.

- __UniFi Internet Controller__ ([Dokumentation](UniFi%20Internet%20Controller))  
	Kurze Beschreibung des Moduls.